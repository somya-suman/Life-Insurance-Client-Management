"""Flask CLI helpers: create the database, add users, load demo data."""
from datetime import date
from pathlib import Path

import click
import pymysql
from werkzeug.security import generate_password_hash

from .db import execute, query

SCHEMA = Path(__file__).resolve().parent.parent / "schema.sql"


def _statements(sql):
    lines = [ln for ln in sql.splitlines() if not ln.strip().startswith("--")]
    return [s.strip() for s in "\n".join(lines).split(";") if s.strip()]


def register(app):
    @app.cli.command("init-db")
    def init_db():
        """Create the database (if missing) and all tables."""
        cfg = app.config
        conn = pymysql.connect(
            host=cfg["DB_HOST"], port=cfg["DB_PORT"], user=cfg["DB_USER"], password=cfg["DB_PASSWORD"]
        )
        with conn.cursor() as cur:
            cur.execute(
                f"CREATE DATABASE IF NOT EXISTS `{cfg['DB_NAME']}` CHARACTER SET utf8mb4"
            )
            cur.execute(f"USE `{cfg['DB_NAME']}`")
            for stmt in _statements(SCHEMA.read_text()):
                cur.execute(stmt)
        conn.commit()
        conn.close()
        click.echo(f"Database '{cfg['DB_NAME']}' is ready.")

    @app.cli.command("create-user")
    @click.option("--username", prompt=True)
    @click.option("--full-name", prompt=True)
    @click.option("--role", type=click.Choice(["admin", "agent"]), default="agent", show_default=True)
    @click.password_option()
    def create_user(username, full_name, role, password):
        """Add a staff login."""
        if len(password) < 8:
            raise click.ClickException("Use a password with at least 8 characters.")
        execute(
            "INSERT INTO users (username, password_hash, full_name, role) VALUES (%s, %s, %s, %s)",
            (username, generate_password_hash(password), full_name, role),
        )
        click.echo(f"Created {role} '{username}'.")

    @app.cli.command("seed-demo")
    def seed_demo():
        """Load a few sample clients, policies and payments for a demo."""
        if query("SELECT COUNT(*) AS n FROM clients", one=True)["n"]:
            raise click.ClickException("Clients already exist; refusing to add demo data.")
        today = date.today()
        clients = [
            ("Asha", "Kulkarni", "1988-04-12", "female", "asha.k@example.com", "9822011223", "Pune", "Maharashtra", "411004"),
            ("Rohan", "Deshmukh", "1979-11-03", "male", "rohan.d@example.com", "9890055667", "Mumbai", "Maharashtra", "400051"),
            ("Meera", "Iyer", "1992-07-25", "female", "meera.i@example.com", "9845098450", "Bengaluru", "Karnataka", "560034"),
        ]
        ids = []
        for first, last, dob, gender, email, phone, city, state, pin in clients:
            ids.append(
                execute(
                    "INSERT INTO clients (first_name, last_name, dob, gender, email, phone, city, state, pincode) "
                    "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                    (first, last, dob, gender, email, phone, city, state, pin),
                )
            )
        policies = [
            (ids[0], "term", 10000000, 14500, "yearly", 30, today.replace(year=today.year - 1)),
            (ids[1], "endowment", 2500000, 6200, "quarterly", 20, today.replace(year=today.year - 2)),
            (ids[2], "ulip", 1500000, 3000, "monthly", 15, today.replace(month=1, day=5)),
        ]
        for n, (cid, plan, sa, prem, freq, term, start) in enumerate(policies, start=1):
            end = start.replace(year=start.year + term)
            pid = execute(
                "INSERT INTO policies (policy_number, client_id, plan_type, sum_assured, premium_amount, "
                "premium_frequency, term_years, start_date, end_date) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                (f"POL-DEMO-{n:04d}", cid, plan, sa, prem, freq, term, start, end),
            )
            execute(
                "INSERT INTO payments (policy_id, amount, paid_on, method) VALUES (%s, %s, %s, 'upi')",
                (pid, prem, start),
            )
        click.echo("Demo data loaded.")
