import secrets
from datetime import date
from decimal import Decimal

from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

from .auth import admin_required, login_required
from .db import execute, paginate, query, transaction
from .utils import (
    FREQUENCIES, PAYMENT_METHODS, PLAN_TYPES, POLICY_STATUSES,
    next_due_date, parse_date, parse_decimal, validate_policy,
)

bp = Blueprint("policies", __name__, url_prefix="/policies")

FIELDS = (
    "client_id", "plan_type", "sum_assured", "premium_amount",
    "premium_frequency", "term_years", "start_date", "end_date",
)


def _get_or_404(policy_id):
    policy = query(
        "SELECT p.*, c.first_name, c.last_name FROM policies p "
        "JOIN clients c ON c.id = p.client_id WHERE p.id = %s",
        (policy_id,),
        one=True,
    )
    if policy is None:
        abort(404)
    return policy


def _clients():
    return query("SELECT id, first_name, last_name, email FROM clients ORDER BY first_name, last_name")


def _new_policy_number():
    while True:
        number = f"POL-{date.today():%Y}-{secrets.token_hex(3).upper()}"
        if not query("SELECT id FROM policies WHERE policy_number = %s", (number,), one=True):
            return number


def _form_ctx(**extra):
    client_options = [
        (c["id"], f"{c['first_name']} {c['last_name']} ({c['email']})") for c in _clients()
    ]
    return dict(
        client_options=client_options, plan_types=PLAN_TYPES, frequencies=FREQUENCIES,
        statuses=POLICY_STATUSES, **extra,
    )


@bp.route("/")
@login_required
def index():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "")
    clauses, args = [], []
    if q:
        clauses.append("(p.policy_number LIKE %s OR CONCAT(c.first_name, ' ', c.last_name) LIKE %s)")
        args += [f"%{q}%"] * 2
    if status in POLICY_STATUSES:
        clauses.append("p.status = %s")
        args.append(status)
    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    base = f"FROM policies p JOIN clients c ON c.id = p.client_id {where}"
    result = paginate(
        f"SELECT p.*, c.first_name, c.last_name {base} ORDER BY p.created_at DESC, p.id DESC",
        f"SELECT COUNT(*) AS n {base}",
        args,
        request.args.get("page", 1, type=int),
    )
    return render_template(
        "policies/list.html", result=result, q=q, status=status, statuses=POLICY_STATUSES
    )


@bp.route("/new", methods=("GET", "POST"))
@login_required
def create():
    errors = {}
    if request.method == "POST":
        errors, data = validate_policy(request.form)
        if "client_id" not in errors and not query(
            "SELECT id FROM clients WHERE id = %s", (data["client_id"],), one=True
        ):
            errors["client_id"] = "That client no longer exists."
        if not errors:
            cols = ", ".join(("policy_number", *FIELDS, "created_by"))
            marks = ", ".join(["%s"] * (len(FIELDS) + 2))
            policy_id = execute(
                f"INSERT INTO policies ({cols}) VALUES ({marks})",
                [_new_policy_number(), *(data[f] for f in FIELDS), g.user["id"]],
            )
            flash("Policy issued.", "success")
            return redirect(url_for("policies.detail", policy_id=policy_id))
        policy = request.form
    else:
        policy = {"client_id": request.args.get("client_id", ""), "start_date": date.today().isoformat()}
    return render_template("policies/form.html", **_form_ctx(policy=policy, errors=errors, mode="new"))


@bp.route("/<int:policy_id>")
@login_required
def detail(policy_id):
    policy = _get_or_404(policy_id)
    payments = query(
        "SELECT * FROM payments WHERE policy_id = %s ORDER BY paid_on DESC, id DESC", (policy_id,)
    )
    claims = query("SELECT * FROM claims WHERE policy_id = %s ORDER BY claim_date DESC", (policy_id,))
    due = None
    if policy["status"] == "active":
        due = next_due_date(
            policy["start_date"], policy["premium_frequency"], len(payments), policy["end_date"]
        )
    return render_template(
        "policies/detail.html", policy=policy, payments=payments, claims=claims, due=due,
        methods=PAYMENT_METHODS, today=date.today(),
        total_paid=sum((p["amount"] for p in payments), Decimal(0)),
    )


@bp.route("/<int:policy_id>/edit", methods=("GET", "POST"))
@login_required
def edit(policy_id):
    policy = _get_or_404(policy_id)
    errors = {}
    if request.method == "POST":
        errors, data = validate_policy(request.form, editing=True)
        if not errors:
            fields = (*FIELDS, "status")
            sets = ", ".join(f"{f} = %s" for f in fields)
            execute(
                f"UPDATE policies SET {sets} WHERE id = %s", [*(data[f] for f in fields), policy_id]
            )
            flash("Policy saved.", "success")
            return redirect(url_for("policies.detail", policy_id=policy_id))
        policy = request.form
    return render_template(
        "policies/form.html",
        **_form_ctx(policy=policy, errors=errors, mode="edit", policy_id=policy_id),
    )


@bp.route("/<int:policy_id>/delete", methods=("POST",))
@admin_required
def delete(policy_id):
    _get_or_404(policy_id)
    execute("DELETE FROM policies WHERE id = %s", (policy_id,))
    flash("Policy deleted along with its payments and claims.", "success")
    return redirect(url_for("policies.index"))


@bp.route("/<int:policy_id>/payments", methods=("POST",))
@login_required
def add_payment(policy_id):
    policy = _get_or_404(policy_id)
    amount = parse_decimal(request.form.get("amount", ""))
    paid_on = parse_date(request.form.get("paid_on", ""))
    method = request.form.get("method", "")
    if policy["status"] != "active":
        flash("Payments can only be recorded on active policies.", "error")
    elif amount is None or amount <= 0 or paid_on is None or method not in PAYMENT_METHODS:
        flash("Enter an amount, a payment date and a payment method.", "error")
    elif paid_on > date.today():
        flash("Payment date cannot be in the future.", "error")
    else:
        execute(
            "INSERT INTO payments (policy_id, amount, paid_on, method, reference_no, notes) "
            "VALUES (%s, %s, %s, %s, %s, %s)",
            (
                policy_id, amount, paid_on, method,
                request.form.get("reference_no", "").strip() or None,
                request.form.get("notes", "").strip() or None,
            ),
        )
        flash("Payment recorded.", "success")
    return redirect(url_for("policies.detail", policy_id=policy_id))


@bp.route("/<int:policy_id>/payments/<int:payment_id>/delete", methods=("POST",))
@admin_required
def delete_payment(policy_id, payment_id):
    execute("DELETE FROM payments WHERE id = %s AND policy_id = %s", (payment_id, policy_id))
    flash("Payment removed.", "success")
    return redirect(url_for("policies.detail", policy_id=policy_id))


@bp.route("/<int:policy_id>/claims", methods=("POST",))
@login_required
def add_claim(policy_id):
    policy = _get_or_404(policy_id)
    amount = parse_decimal(request.form.get("claim_amount", ""))
    claim_date = parse_date(request.form.get("claim_date", ""))
    reason = request.form.get("reason", "").strip()
    if policy["status"] != "active":
        flash("Claims can only be filed on active policies.", "error")
    elif not reason or claim_date is None or amount is None or amount <= 0:
        flash("Enter a claim date, an amount and a reason.", "error")
    elif amount > policy["sum_assured"]:
        flash("Claim amount cannot exceed the sum assured.", "error")
    else:
        execute(
            "INSERT INTO claims (policy_id, claim_date, claim_amount, reason) VALUES (%s, %s, %s, %s)",
            (policy_id, claim_date, amount, reason[:255]),
        )
        flash("Claim filed and waiting for a decision.", "success")
    return redirect(url_for("policies.detail", policy_id=policy_id))


@bp.route("/<int:policy_id>/claims/<int:claim_id>/decide", methods=("POST",))
@admin_required
def decide_claim(policy_id, claim_id):
    decision = request.form.get("decision")
    claim = query(
        "SELECT * FROM claims WHERE id = %s AND policy_id = %s", (claim_id, policy_id), one=True
    )
    if claim is None:
        abort(404)
    if claim["status"] != "pending" or decision not in ("approved", "rejected"):
        flash("This claim has already been decided.", "error")
        return redirect(url_for("policies.detail", policy_id=policy_id))

    statements = [
        ("UPDATE claims SET status = %s, resolved_at = NOW() WHERE id = %s", (decision, claim_id))
    ]
    if decision == "approved":  # approving closes the policy, atomically with the claim update
        statements.append(("UPDATE policies SET status = 'claimed' WHERE id = %s", (policy_id,)))
    transaction(statements)
    flash(f"Claim {decision}.", "success")
    return redirect(url_for("policies.detail", policy_id=policy_id))
