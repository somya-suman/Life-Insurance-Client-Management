from datetime import date, timedelta

from flask import Blueprint, render_template

from .auth import login_required
from .db import query
from .utils import next_due_date

bp = Blueprint("dashboard", __name__)


@bp.route("/")
@login_required
def index():
    today = date.today()
    month_start = today.replace(day=1)

    stats = {
        "clients": query("SELECT COUNT(*) AS n FROM clients", one=True)["n"],
        "active": query(
            "SELECT COUNT(*) AS n, COALESCE(SUM(sum_assured), 0) AS total "
            "FROM policies WHERE status = 'active'",
            one=True,
        ),
        "collected": query(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE paid_on >= %s",
            (month_start,),
            one=True,
        )["total"],
        "pending_claims": query(
            "SELECT COUNT(*) AS n FROM claims WHERE status = 'pending'", one=True
        )["n"],
    }

    # Premium follow-ups: next instalment due within 30 days, or already overdue.
    rows = query(
        """
        SELECT p.id, p.policy_number, p.premium_amount, p.premium_frequency,
               p.start_date, p.end_date, c.id AS client_id, c.first_name, c.last_name, c.phone,
               (SELECT COUNT(*) FROM payments pay WHERE pay.policy_id = p.id) AS paid_count
        FROM policies p JOIN clients c ON c.id = p.client_id
        WHERE p.status = 'active'
        """
    )
    horizon = today + timedelta(days=30)
    follow_ups = []
    for r in rows:
        due = next_due_date(r["start_date"], r["premium_frequency"], r["paid_count"], r["end_date"])
        if due and due <= horizon:
            r["due"] = due
            r["overdue"] = due < today
            follow_ups.append(r)
    follow_ups.sort(key=lambda r: r["due"])

    recent = query(
        """
        SELECT pay.amount, pay.paid_on, p.id AS policy_id, p.policy_number, c.first_name, c.last_name
        FROM payments pay
        JOIN policies p ON p.id = pay.policy_id
        JOIN clients c ON c.id = p.client_id
        ORDER BY pay.paid_on DESC, pay.id DESC LIMIT 6
        """
    )
    return render_template(
        "dashboard.html", stats=stats, follow_ups=follow_ups[:12], recent=recent, today=today
    )
