import pymysql
from flask import Blueprint, flash, redirect, render_template, request, url_for

from .auth import admin_required, login_required
from .db import execute, paginate, query
from .utils import GENDERS, validate_client

bp = Blueprint("clients", __name__, url_prefix="/clients")

FIELDS = (
    "first_name", "last_name", "dob", "gender", "email", "phone",
    "address", "city", "state", "pincode", "nominee_name", "nominee_relation",
)


def _get_or_404(client_id):
    client = query("SELECT * FROM clients WHERE id = %s", (client_id,), one=True)
    if client is None:
        from flask import abort

        abort(404)
    return client


def _email_taken(email, exclude_id=None):
    row = query(
        "SELECT id FROM clients WHERE email = %s AND id <> %s", (email, exclude_id or 0), one=True
    )
    return row is not None


@bp.route("/")
@login_required
def index():
    q = request.args.get("q", "").strip()
    where, args = "", []
    if q:
        where = "WHERE CONCAT(c.first_name, ' ', c.last_name) LIKE %s OR c.email LIKE %s OR c.phone LIKE %s"
        args = [f"%{q}%"] * 3
    result = paginate(
        "SELECT c.*, (SELECT COUNT(*) FROM policies p WHERE p.client_id = c.id) AS policy_count "
        f"FROM clients c {where} ORDER BY c.created_at DESC, c.id DESC",
        f"SELECT COUNT(*) AS n FROM clients c {where}",
        args,
        request.args.get("page", 1, type=int),
    )
    return render_template("clients/list.html", result=result, q=q)


@bp.route("/new", methods=("GET", "POST"))
@login_required
def create():
    errors = {}
    if request.method == "POST":
        errors, data = validate_client(request.form)
        if "email" not in errors and _email_taken(data["email"]):
            errors["email"] = "Another client already uses this email."
        if not errors:
            cols = ", ".join(FIELDS)
            marks = ", ".join(["%s"] * len(FIELDS))
            client_id = execute(
                f"INSERT INTO clients ({cols}) VALUES ({marks})", [data[f] for f in FIELDS]
            )
            flash("Client added.", "success")
            return redirect(url_for("clients.detail", client_id=client_id))
    return render_template(
        "clients/form.html", client=request.form, errors=errors, genders=GENDERS, mode="new"
    )


@bp.route("/<int:client_id>")
@login_required
def detail(client_id):
    client = _get_or_404(client_id)
    policies = query(
        "SELECT * FROM policies WHERE client_id = %s ORDER BY start_date DESC", (client_id,)
    )
    return render_template("clients/detail.html", client=client, policies=policies)


@bp.route("/<int:client_id>/edit", methods=("GET", "POST"))
@login_required
def edit(client_id):
    client = _get_or_404(client_id)
    errors = {}
    if request.method == "POST":
        errors, data = validate_client(request.form)
        if "email" not in errors and _email_taken(data["email"], client_id):
            errors["email"] = "Another client already uses this email."
        if not errors:
            sets = ", ".join(f"{f} = %s" for f in FIELDS)
            execute(
                f"UPDATE clients SET {sets} WHERE id = %s", [*(data[f] for f in FIELDS), client_id]
            )
            flash("Client details saved.", "success")
            return redirect(url_for("clients.detail", client_id=client_id))
        client = request.form
    return render_template(
        "clients/form.html", client=client, errors=errors, genders=GENDERS, mode="edit",
        client_id=client_id,
    )


@bp.route("/<int:client_id>/delete", methods=("POST",))
@admin_required
def delete(client_id):
    _get_or_404(client_id)
    try:
        execute("DELETE FROM clients WHERE id = %s", (client_id,))
    except pymysql.err.IntegrityError:
        flash("This client still has policies. Remove or reassign them first.", "error")
        return redirect(url_for("clients.detail", client_id=client_id))
    flash("Client deleted.", "success")
    return redirect(url_for("clients.index"))
