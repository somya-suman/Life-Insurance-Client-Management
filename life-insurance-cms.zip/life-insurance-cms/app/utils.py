"""Validation and small helpers. No database access here, so it is easy to unit-test."""
import re
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

from dateutil.relativedelta import relativedelta

GENDERS = ["male", "female", "other"]
PLAN_TYPES = ["term", "whole_life", "endowment", "money_back", "ulip"]
FREQUENCIES = ["monthly", "quarterly", "half_yearly", "yearly"]
POLICY_STATUSES = ["active", "lapsed", "matured", "surrendered", "claimed"]
PAYMENT_METHODS = ["cash", "cheque", "upi", "card", "net_banking"]
FREQ_MONTHS = {"monthly": 1, "quarterly": 3, "half_yearly": 6, "yearly": 12}

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^\+?\d{10,13}$")
PINCODE_RE = re.compile(r"^\d{6}$")


def label(value):
    """'half_yearly' -> 'Half yearly'"""
    return str(value).replace("_", " ").capitalize()


def parse_date(value):
    try:
        return datetime.strptime((value or "").strip(), "%Y-%m-%d").date()
    except ValueError:
        return None


def parse_decimal(value):
    try:
        d = Decimal((value or "").strip())
    except InvalidOperation:
        return None
    return d if d.is_finite() else None


def inr(value):
    """Format a number as rupees using Indian digit grouping: 1234567.5 -> ₹12,34,567.50"""
    d = Decimal(value or 0)
    whole, dec = f"{abs(d):.2f}".split(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        head = re.sub(r"(\d)(?=(\d\d)+$)", r"\1,", head)
        whole = f"{head},{tail}"
    return f"{'-' if d < 0 else ''}₹{whole}.{dec}"


def dmy(value):
    return value.strftime("%d %b %Y") if value else "-"


def validate_client(form):
    """Return (errors, cleaned). `cleaned` maps straight onto the clients table columns."""
    errors = {}
    g = lambda k: (form.get(k) or "").strip()  # noqa: E731

    first, last = g("first_name"), g("last_name")
    if not first:
        errors["first_name"] = "Enter a first name."
    if not last:
        errors["last_name"] = "Enter a last name."

    dob = parse_date(g("dob"))
    if dob is None:
        errors["dob"] = "Enter a valid date of birth."
    elif dob >= date.today():
        errors["dob"] = "Date of birth must be in the past."

    if g("gender") not in GENDERS:
        errors["gender"] = "Choose a gender."

    email = g("email").lower()
    if not EMAIL_RE.match(email):
        errors["email"] = "Enter a valid email address."

    phone = re.sub(r"[\s-]", "", g("phone"))
    if not PHONE_RE.match(phone):
        errors["phone"] = "Enter a phone number with 10 to 13 digits."

    pincode = g("pincode")
    if pincode and not PINCODE_RE.match(pincode):
        errors["pincode"] = "Pincode must be 6 digits."

    cleaned = {
        "first_name": first,
        "last_name": last,
        "dob": dob,
        "gender": g("gender"),
        "email": email,
        "phone": phone,
        "address": g("address") or None,
        "city": g("city") or None,
        "state": g("state") or None,
        "pincode": pincode or None,
        "nominee_name": g("nominee_name") or None,
        "nominee_relation": g("nominee_relation") or None,
    }
    return errors, cleaned


def validate_policy(form, editing=False):
    errors = {}
    g = lambda k: (form.get(k) or "").strip()  # noqa: E731

    try:
        client_id = int(g("client_id"))
    except ValueError:
        client_id = None
        errors["client_id"] = "Choose a client."

    if g("plan_type") not in PLAN_TYPES:
        errors["plan_type"] = "Choose a plan type."
    if g("premium_frequency") not in FREQUENCIES:
        errors["premium_frequency"] = "Choose how often the premium is paid."

    sum_assured = parse_decimal(g("sum_assured"))
    if sum_assured is None or sum_assured <= 0:
        errors["sum_assured"] = "Enter a sum assured greater than zero."
    premium = parse_decimal(g("premium_amount"))
    if premium is None or premium <= 0:
        errors["premium_amount"] = "Enter a premium greater than zero."
    elif sum_assured and sum_assured > 0 and premium > sum_assured:
        errors["premium_amount"] = "Premium cannot exceed the sum assured."

    try:
        term = int(g("term_years"))
        if not 1 <= term <= 60:
            raise ValueError
    except ValueError:
        term = None
        errors["term_years"] = "Term must be between 1 and 60 years."

    start = parse_date(g("start_date"))
    if start is None:
        errors["start_date"] = "Enter a valid start date."

    status = g("status") or "active"
    if editing and status not in POLICY_STATUSES:
        errors["status"] = "Choose a status."

    end = start + relativedelta(years=term) if start and term else None
    cleaned = {
        "client_id": client_id,
        "plan_type": g("plan_type"),
        "sum_assured": sum_assured,
        "premium_amount": premium,
        "premium_frequency": g("premium_frequency"),
        "term_years": term,
        "start_date": start,
        "end_date": end,
    }
    if editing:
        cleaned["status"] = status
    return errors, cleaned


def next_due_date(start_date, frequency, paid_count, end_date=None):
    """Date the next premium falls due, assuming one payment per instalment.

    Returns None once the policy term has no more instalments left.
    """
    due = start_date + relativedelta(months=FREQ_MONTHS[frequency] * paid_count)
    if end_date and due >= end_date:
        return None
    return due
