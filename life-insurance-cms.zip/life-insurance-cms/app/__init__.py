from flask import Flask, render_template
from flask_wtf.csrf import CSRFProtect

from . import auth, cli, clients, dashboard, db, policies
from .config import Config
from .utils import dmy, inr, label

csrf = CSRFProtect()


def create_app(config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if config:
        app.config.update(config)

    csrf.init_app(app)
    app.teardown_appcontext(db.close_db)

    app.jinja_env.filters.update(inr=inr, dmy=dmy, label=label)

    for module in (auth, dashboard, clients, policies):
        app.register_blueprint(module.bp)
    cli.register(app)

    @app.errorhandler(404)
    def not_found(_e):
        return render_template("errors/404.html"), 404

    return app
