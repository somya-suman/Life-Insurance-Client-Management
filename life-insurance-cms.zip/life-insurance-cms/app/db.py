"""Thin MySQL helpers built on PyMySQL. All queries are parameterised."""
import math

import pymysql
from flask import current_app, g


def get_db():
    if "db" not in g:
        cfg = current_app.config
        g.db = pymysql.connect(
            host=cfg["DB_HOST"],
            port=cfg["DB_PORT"],
            user=cfg["DB_USER"],
            password=cfg["DB_PASSWORD"],
            database=cfg["DB_NAME"],
            charset="utf8mb4",
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=False,
        )
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def query(sql, args=(), one=False):
    with get_db().cursor() as cur:
        cur.execute(sql, args)
        rows = cur.fetchall()
    if one:
        return rows[0] if rows else None
    return rows


def execute(sql, args=()):
    """Run one write statement, commit, and return the new row id."""
    return transaction([(sql, args)])


def transaction(statements):
    """Run several write statements atomically. Returns the first statement's lastrowid."""
    db = get_db()
    try:
        first_id = None
        with db.cursor() as cur:
            for i, (sql, args) in enumerate(statements):
                cur.execute(sql, args)
                if i == 0:
                    first_id = cur.lastrowid
        db.commit()
        return first_id
    except Exception:
        db.rollback()
        raise


def paginate(select_sql, count_sql, args, page, per_page=10):
    total = query(count_sql, args, one=True)["n"]
    pages = max(1, math.ceil(total / per_page))
    page = min(max(page, 1), pages)
    items = query(f"{select_sql} LIMIT %s OFFSET %s", [*args, per_page, (page - 1) * per_page])
    return {"items": items, "page": page, "pages": pages, "total": total}
