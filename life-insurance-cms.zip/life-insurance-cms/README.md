# Lifeline: Life Insurance Client Management

A web application for insurance staff to manage clients, issue policies, record premium payments and handle claims. Built with **Python (Flask)** and **MySQL**, using plain parameterised SQL through PyMySQL (no ORM) so every query is easy to read and review.

![Python](https://img.shields.io/badge/python-3.10%2B-blue) ![MySQL](https://img.shields.io/badge/MySQL-8.0-orange) ![License](https://img.shields.io/badge/license-MIT-green)

## Features

- **Staff login** with hashed passwords (Werkzeug) and two roles: `admin` and `agent`
- **Clients**: add, edit, search (name, email, phone), paginated list, nominee details
- **Policies**: issue term, whole life, endowment, money-back and ULIP plans; auto-generated policy numbers; end date calculated from the term; status tracking (active, lapsed, matured, surrendered, claimed)
- **Premium payments**: record payments per policy, with method and reference number
- **Premium follow-ups**: the dashboard lists premiums that are overdue or due in the next 30 days, calculated from the payment frequency and payments made
- **Claims**: staff file claims; admins approve or reject. Approving a claim marks the policy as claimed in the same database transaction
- **Dashboard**: client count, policies in force, sum assured, premiums collected this month, claims waiting
- **Security**: CSRF protection on every form, parameterised SQL, safe redirects after login, role checks on destructive actions
- Amounts shown in rupees with Indian digit grouping (₹12,34,567.00)

## Tech stack

| Layer | Choice |
|-------|--------|
| Backend | Flask 3, Blueprints |
| Database | MySQL 8 (InnoDB, foreign keys, CHECK constraints) via PyMySQL |
| Frontend | Jinja2 templates, hand-written CSS (no framework) |
| Tests | pytest, GitHub Actions |

## Database design

```mermaid
erDiagram
    users ||--o{ policies : "issues"
    clients ||--o{ policies : "holds"
    policies ||--o{ payments : "receives"
    policies ||--o{ claims : "has"
    clients { int id PK
              varchar email UK
              date dob }
    policies { int id PK
               varchar policy_number UK
               int client_id FK
               enum plan_type
               decimal sum_assured
               decimal premium_amount
               enum premium_frequency
               enum status }
    payments { int id PK
               int policy_id FK
               decimal amount
               date paid_on }
    claims { int id PK
             int policy_id FK
             decimal claim_amount
             enum status }
    users { int id PK
            varchar username UK
            enum role }
```

Deleting a client who still has policies is blocked (`ON DELETE RESTRICT`). Deleting a policy removes its payments and claims (`ON DELETE CASCADE`). The full DDL is in [`schema.sql`](schema.sql).

## Getting started

### 1. Prerequisites

- Python 3.10 or newer
- MySQL 8 running locally (or MariaDB 10.5+)

### 2. Install

```bash
git clone https://github.com/<your-username>/life-insurance-cms.git
cd life-insurance-cms

python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Configure

```bash
cp .env.example .env              # Windows: copy .env.example .env
```

Edit `.env` with your MySQL user and password, and set `SECRET_KEY` to a long random string:

```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

### 4. Create the database and a login

```bash
flask --app run init-db           # creates the database and all tables
flask --app run create-user       # prompts for username, name, role and password
flask --app run seed-demo         # optional: sample clients, policies and payments
```

Create at least one `admin` user. Admins can delete records and decide claims; agents cannot.

### 5. Run

```bash
flask --app run run --debug
```

Open <http://127.0.0.1:5000> and log in.

## Running the tests

```bash
pytest
```

The unit tests cover input validation, premium due-date calculation and currency formatting. They do not need a database.

## Project structure

```
life-insurance-cms/
├── app/
│   ├── __init__.py        # app factory, blueprints, template filters
│   ├── config.py          # settings read from .env
│   ├── db.py              # MySQL connection, query/execute/transaction, pagination
│   ├── auth.py            # login, logout, login_required, admin_required
│   ├── dashboard.py       # summary figures and premium follow-ups
│   ├── clients.py         # client CRUD
│   ├── policies.py        # policies, payments, claims
│   ├── utils.py           # validators, due-date logic, formatting
│   ├── cli.py             # init-db, create-user, seed-demo commands
│   ├── templates/
│   └── static/css/style.css
├── tests/test_utils.py
├── schema.sql
├── run.py
├── requirements.txt
└── .env.example
```

## Notes for production use

- Run behind a production WSGI server (for example `gunicorn "app:create_app()"`) over HTTPS, and set `SESSION_COOKIE_SECURE=True`.
- Use a dedicated MySQL user with privileges on this database only, not `root`.
- Premium due dates assume one payment per instalment. A full ledger with partial payments, grace periods and automatic lapsing would be the natural next step.
- This project stores personal data. Review your local data-protection obligations before using it with real clients.

## Ideas for future work

- Export clients and payments to CSV or PDF
- Automatic policy lapsing after a grace period
- Email or SMS premium reminders
- Audit log of who changed what
- Docker Compose file for one-command setup

## License

Released under the [MIT License](LICENSE).
