from datetime import date, timedelta

from app.utils import inr, next_due_date, validate_client, validate_policy

GOOD_CLIENT = {
    "first_name": "Asha", "last_name": "Kulkarni", "dob": "1988-04-12", "gender": "female",
    "email": "Asha.K@Example.com", "phone": "98220 11223", "pincode": "411004",
}
GOOD_POLICY = {
    "client_id": "3", "plan_type": "term", "sum_assured": "5000000", "premium_amount": "12000",
    "premium_frequency": "yearly", "term_years": "20", "start_date": "2026-01-15",
}


def test_valid_client_is_cleaned():
    errors, data = validate_client(GOOD_CLIENT)
    assert errors == {}
    assert data["email"] == "asha.k@example.com"
    assert data["phone"] == "9822011223"
    assert data["address"] is None


def test_client_rejects_bad_input():
    bad = {**GOOD_CLIENT, "email": "nope", "phone": "123", "pincode": "12", "gender": "x",
           "dob": (date.today() + timedelta(days=1)).isoformat(), "first_name": " "}
    errors, _ = validate_client(bad)
    assert set(errors) == {"first_name", "dob", "gender", "email", "phone", "pincode"}


def test_valid_policy_computes_end_date():
    errors, data = validate_policy(GOOD_POLICY)
    assert errors == {}
    assert data["end_date"] == date(2046, 1, 15)


def test_policy_rejects_bad_numbers():
    errors, _ = validate_policy({**GOOD_POLICY, "sum_assured": "-1", "term_years": "0"})
    assert "sum_assured" in errors and "term_years" in errors


def test_premium_cannot_exceed_sum_assured():
    errors, _ = validate_policy({**GOOD_POLICY, "sum_assured": "1000", "premium_amount": "5000"})
    assert "premium_amount" in errors


def test_edit_requires_valid_status():
    errors, _ = validate_policy({**GOOD_POLICY, "status": "bogus"}, editing=True)
    assert "status" in errors


def test_next_due_date_by_frequency():
    start = date(2026, 1, 31)
    assert next_due_date(start, "monthly", 1) == date(2026, 2, 28)
    assert next_due_date(start, "quarterly", 2) == date(2026, 7, 31)
    assert next_due_date(start, "yearly", 0) == start


def test_next_due_date_none_after_term_ends():
    assert next_due_date(date(2026, 1, 1), "yearly", 5, end_date=date(2031, 1, 1)) is None


def test_inr_uses_indian_grouping():
    assert inr(0) == "₹0.00"
    assert inr(999) == "₹999.00"
    assert inr(1234567.5) == "₹12,34,567.50"
    assert inr(-100000) == "-₹1,00,000.00"
