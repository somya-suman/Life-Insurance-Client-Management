-- Life Insurance Client Management: MySQL 8 schema
-- Create the database first, then load this file:
--   mysql -u root -p -e "CREATE DATABASE life_insurance_db CHARACTER SET utf8mb4"
--   mysql -u root -p life_insurance_db < schema.sql
-- (or just run: flask --app run init-db)

CREATE TABLE IF NOT EXISTS users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50)  NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(100) NOT NULL,
    role          ENUM('admin','agent') NOT NULL DEFAULT 'agent',
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS clients (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    first_name        VARCHAR(60)  NOT NULL,
    last_name         VARCHAR(60)  NOT NULL,
    dob               DATE         NOT NULL,
    gender            ENUM('male','female','other') NOT NULL,
    email             VARCHAR(120) NOT NULL UNIQUE,
    phone             VARCHAR(15)  NOT NULL,
    address           VARCHAR(255) NULL,
    city              VARCHAR(80)  NULL,
    state             VARCHAR(80)  NULL,
    pincode           CHAR(6)      NULL,
    nominee_name      VARCHAR(100) NULL,
    nominee_relation  VARCHAR(50)  NULL,
    created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_clients_name (last_name, first_name),
    INDEX idx_clients_phone (phone)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS policies (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    policy_number      VARCHAR(30)  NOT NULL UNIQUE,
    client_id          INT          NOT NULL,
    plan_type          ENUM('term','whole_life','endowment','money_back','ulip') NOT NULL,
    sum_assured        DECIMAL(14,2) NOT NULL CHECK (sum_assured > 0),
    premium_amount     DECIMAL(12,2) NOT NULL CHECK (premium_amount > 0),
    premium_frequency  ENUM('monthly','quarterly','half_yearly','yearly') NOT NULL,
    term_years         SMALLINT     NOT NULL CHECK (term_years BETWEEN 1 AND 60),
    start_date         DATE         NOT NULL,
    end_date           DATE         NOT NULL,
    status             ENUM('active','lapsed','matured','surrendered','claimed') NOT NULL DEFAULT 'active',
    created_by         INT          NULL,
    created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_policy_client FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE RESTRICT,
    CONSTRAINT fk_policy_user   FOREIGN KEY (created_by) REFERENCES users(id)  ON DELETE SET NULL,
    INDEX idx_policies_status (status),
    INDEX idx_policies_client (client_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payments (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    policy_id     INT NOT NULL,
    amount        DECIMAL(12,2) NOT NULL CHECK (amount > 0),
    paid_on       DATE NOT NULL,
    method        ENUM('cash','cheque','upi','card','net_banking') NOT NULL,
    reference_no  VARCHAR(60) NULL,
    notes         VARCHAR(255) NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_payment_policy FOREIGN KEY (policy_id) REFERENCES policies(id) ON DELETE CASCADE,
    INDEX idx_payments_paid_on (paid_on)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS claims (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    policy_id     INT NOT NULL,
    claim_date    DATE NOT NULL,
    claim_amount  DECIMAL(14,2) NOT NULL CHECK (claim_amount > 0),
    reason        VARCHAR(255) NOT NULL,
    status        ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    resolved_at   TIMESTAMP NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_claim_policy FOREIGN KEY (policy_id) REFERENCES policies(id) ON DELETE CASCADE,
    INDEX idx_claims_status (status)
) ENGINE=InnoDB;
